#ifndef Project_Two_Header_Files_IntCalc_h_
#define Project_Two_Header_Files_IntCalc_h_
#pragma once
class IntCalc
{
public:
	IntCalc();		// Declaration of default constructor 
					// Setters & getters
	void setInitialDeposit(double t_initialDeposit);
	void setMonthlyDeposit(double t_monthlyDeposit);
	void setPercentInterest(double t_percentInterest);
	void setNumberYears(int t_numberYears);

	double getInitialDeposit();
	double getMonthlyDeposit();
	double getPercentInterest();
	int getNumberYears();

					//Function for Calculating a Monthly Balance
	double monthlyBalance(int t_months, double t_monthDeposit);

					//Function for Calculating the Monthly Interest
	double monthlyInterest(int t_months, double t_monthDeposit);

					//Function for Calculating the Annual Balance
	double annualBalance(int t_numYears, double t_depositAmount);

					//Function for Calculating the Annual Interest
	double annualInterest(int t_numYears, double t_depositAmount);

					//Function for Displaying Output
	void showReport(double t_monthlyDep);

private:
	double initialDeposit;
	double monthlyDeposit;
	double percentInterest;
	int numberYears;
};

#endif // Project_Two_Header_Files_IntCalc_h_