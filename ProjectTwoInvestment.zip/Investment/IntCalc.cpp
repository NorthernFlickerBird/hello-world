#include "IntCalc.h"
#include <iostream>
#include <iomanip>
using namespace std;

					//Default constructor
IntCalc::IntCalc() {
	initialDeposit = 0.00;
	monthlyDeposit = 0.00;
	percentInterest = 0.00;
	numberYears = 0;
}

					//Setters and getters
void IntCalc::setInitialDeposit(double t_initialDeposit) {
	initialDeposit = t_initialDeposit;
}
void IntCalc::setMonthlyDeposit(double t_monthlyDeposit) {
	monthlyDeposit = t_monthlyDeposit;
}
void IntCalc::setPercentInterest(double t_percentInterest) {
	percentInterest = t_percentInterest;
}
void IntCalc::setNumberYears(int t_numberYears) {
	numberYears = t_numberYears;
}
double IntCalc::getInitialDeposit() {
	return initialDeposit;
}
double IntCalc::getMonthlyDeposit() {
	return monthlyDeposit;
}
double IntCalc::getPercentInterest() {
	return percentInterest;
}
int IntCalc::getNumberYears() {
	return numberYears;
}

					//Function for Calculating Monthly Balance: Calculates requested number of months, including interest
double IntCalc::monthlyBalance(int t_months, double t_monthDeposit) {
	double balAmount = getInitialDeposit();
	for (int i = 0; i < t_months; i++) {
		balAmount = balAmount + t_monthDeposit;
		balAmount = balAmount + ((balAmount * getPercentInterest() / 100) / 12);
	}
	return balAmount;
}
					//Function for Calculating Monthly Interest: Calculates singular month interest
double IntCalc::monthlyInterest(int t_months, double t_monthDeposit) {
	double intAmount;
	double monthlyInterestRate = (getPercentInterest() / 100) / 12;
	intAmount = (monthlyBalance(t_months - 1, t_monthDeposit) + t_monthDeposit) * monthlyInterestRate;
	return intAmount;
}

					//Function for Calculating Annual Balance: Calculates the running total balance year over year
double IntCalc::annualBalance(int t_numYears, double t_depositAmount) {
	int numMonths;
	double annualBal = 0.00;
	numMonths = t_numYears * 12;
	for (int i = 0; i < t_numYears; i++) {
		annualBal = monthlyBalance(numMonths, t_depositAmount);
	}
	return annualBal;
}
					/* Function for Calculating Annual Interest 
					Calculates for all years, then deletes all except current year, so "5" calculates interest for 5 years
					and then subtracts the first 4 years, to get accurate yearly interest.
					*/
double IntCalc::annualInterest(int t_numYears, double t_depositAmount) {
	int numMonths;
	double annualInt = 0.00;
	double priorYears = 0.00;
	numMonths = t_numYears * 12;
	for (int i = 0; i < numMonths; i++) {
		annualInt = annualInt + monthlyInterest(i + 1, t_depositAmount);
	}
	for (int j = 0; j < numMonths - 12; j++) {
		priorYears = priorYears - monthlyInterest(j + 1, t_depositAmount);
	}
	annualInt = annualInt + priorYears;
	return annualInt;
}
					//function to display data (can be used both with and without monthly deposits. Use 0 for without.
void IntCalc::showReport(double t_monthlyDep) {
	cout << " Balance and Interest Without Additional Monthly Deposits " << endl;
	cout << "--------------------------------------------------------------" << endl;
	cout << "--------------------------------------------------------------" << endl;
	cout << " Year " << " Year End Balance " << " Year End Earned Interest" << endl;
		cout << "--------------------------------------------------------------" << endl;

	cout << setprecision(2) << fixed << endl;			//Displays rounded values
	for (int i = 0; i < getNumberYears(); i++) {
		cout << " " << i + 1 << " " << annualBalance(i + 1,	t_monthlyDep) << " " << annualInterest(i + 1, t_monthlyDep) << endl;
	}
	return;
}